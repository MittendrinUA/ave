$(document).ready(function() {
    $('.header_burger').click(function(event) {
        $('.header_burger,.mainHeader--nav,.mainHeader--logo,.mainHeader--top').toggleClass('active');
    });
});